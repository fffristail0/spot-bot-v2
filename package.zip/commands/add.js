const addSpotWizard = require('../scenes/addSpotWizard/addSpotWizard.js');

module.exports = async (ctx) => {
    ctx.scene.enter('addSpotWizard')
}